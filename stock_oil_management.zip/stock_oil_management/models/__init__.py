# -*- coding: utf-8 -*-

from . import product_inherit
from . import stock_move_inherit
from . import stock_picking_inherit
from . import transport
from . import sale_order_inherit
from . import ilot
from . import regime_douanier
from . import stock_rule_inherit
from . import stock_inventory_inherit
