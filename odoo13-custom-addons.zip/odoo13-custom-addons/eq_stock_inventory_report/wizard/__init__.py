# -*- coding: utf-8 -*-
##############################################################################
#
# Copyright 2019 EquickERP
#
##############################################################################


from . import wizard_stock_inventory

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: