# -*- coding: utf-8 -*-
##############################################################################
#
# Copyright 2019 EquickERP
#
##############################################################################


from . import wizard
from . import report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: