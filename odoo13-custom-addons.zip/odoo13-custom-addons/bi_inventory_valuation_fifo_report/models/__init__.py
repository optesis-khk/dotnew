# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.


from. import sales_daybook_report_product_category_wizard
from . import sales_daybook_product_category_template

